CS584 HOMEWORK 3
NAME : Preeti Bhattacharya (G01302375)

READ ME FILE

How to run my code.



1) Use .ipnyb extension file on to google collab Pro(I used google collab because my system was crashing or was taking too long to execute).
2) Import 1646102559_507402_train35.txt file for training data set.
3) Import 1646102559_513849_test35-nolabels.txt file for testing data set.
4) Run the code in google collab for each cell.
5) In the cell where I've AdaBoost().fit(x_train, y_train, iters=200) please change the iterations "iters" to get error rate and accuracy of my training model.
6) We then write output to a text file, which can be found in file section of google collab.





